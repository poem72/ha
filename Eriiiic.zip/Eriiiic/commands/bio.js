const fetch = require('node-fetch');
const fs = require('fs');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages
const bioFilePath = './bio.txt'; // Path to the bio.txt file

module.exports = {
    names: {
        list: ["bio"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Read the bios from bio.txt
            fs.readFile(bioFilePath, 'utf8', async (err, data) => {
                if (err) {
                    console.error("Error reading bio.txt file:", err);
                    targetChannel.send("Failed to read bio file.");
                    return;
                }

                // Split the file contents into an array of bios (assuming each line is a bio)
                const bios = data.split('\n').filter(line => line.trim() !== '');

                if (bios.length === 0) {
                    targetChannel.send("Bio file is empty.");
                    return;
                }

                // Pick a random bio from the array
                const randomBio = bios[Math.floor(Math.random() * bios.length)];

                // Make the PATCH request to update the bot's bio
                const response = await fetch('https://discord.com/api/v9/users/@me', {
                    method: 'PATCH',
                    headers: {
                        'Authorization': `Bot ${client.token}`, // Bot token for authentication
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        bio: randomBio
                    })
                });

                if (response.ok) {
                    targetChannel.send(`Bot bio updated to: "${randomBio}"`);
                } else {
                    targetChannel.send("Failed to update the bot's bio.");
                    console.error('Error updating bio:', await response.json());
                }
            });

        } catch (error) {
            console.error("Error occurred while updating the bio:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to update the bot's bio.");
        }
    }
};
