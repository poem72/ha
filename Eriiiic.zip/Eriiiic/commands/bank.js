const allowedUsers = require("../allowed.json").allowed;
const messages = require("../bank.json").messages; // Assuming your JSON file is named bank.json
const targetChannelId = '1284204173772062815'; // Channel to send bot messages
let interval = null; // Store the message interval
let stopLoop = false; // Control flag for stopping the loop

module.exports = {
    names: {
        list: ["bank", "bankstop"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Handle the stop command
            if (message.content.startsWith('bankstop')) {
                if (interval) {
                    clearInterval(interval); // Stop the interval
                    interval = null; // Reset the interval
                    targetChannel.send(`Bank stopped, no more random messages in this channel.`);
                    stopLoop = true; // Stop the loop flag
                } else {
                    targetChannel.send("The bank process is not running.");
                }
                return; // Exit the function
            }

            // Proceed with the normal bank process
            if (args.length < 1) {
                targetChannel.send("Please provide a text channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_TEXT') {
                targetChannel.send("Please provide a valid text channel ID.");
                return;
            }

            stopLoop = false; // Reset the stop flag

            // Function to send a random message
            const sendRandomMessage = async () => {
                if (stopLoop) return; // Stop if flag is set
                const randomMessage = messages[Math.floor(Math.random() * messages.length)];
                await channel.send(randomMessage);
            };

            const startBankMessages = async () => {
                if (stopLoop) return; // Stop if the loop flag is set

                // Send a random message immediately
                await sendRandomMessage();

                // Send a random message every 5 minutes (300000 milliseconds)
                interval = setInterval(async () => {
                    await sendRandomMessage();
                }, 300000); // 5 minutes in milliseconds
            };

            // Start the bank process (send messages)
            startBankMessages();

            targetChannel.send(`**Started playing bank in ${channel.toString()}.**`);

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to start the bank process.");
        }
    }
};
