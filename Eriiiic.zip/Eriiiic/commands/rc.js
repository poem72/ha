const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["reactstart", "reactstop"]
    },
    run: async (client, message, args) => {
        try {
            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                message.channel.send("You don't have permission to use this command.");
                return;
            }

            // Check if the user provided a text channel ID and an emoji
            if (args.length < 2) {
                message.channel.send("Please provide a text channel ID and an emoji.");
                return;
            }

            const textChannelId = args[0];
            const emoji = args[1];

            // Fetch the text channel
            const textChannel = client.channels.cache.get(textChannelId);
            if (!textChannel || textChannel.type !== 'GUILD_TEXT') {
                message.channel.send("Please provide a valid text channel ID.");
                return;
            }

            // Stop the reaction listener if 'reactstop' is triggered
            if (message.content.startsWith('reactstop')) {
                if (client.reactionListeners && client.reactionListeners[textChannelId]) {
                    client.reactionListeners[textChannelId].stop();
                    message.channel.send(`Stopped reacting in the channel ${textChannel.name}`);
                } else {
                    message.channel.send("The bot is not reacting in that channel.");
                }
                return;
            }

            // Start listening for new messages in the specified channel
            const messageListener = textChannel.createMessageCollector();

            message.channel.send(`Started reacting with ${emoji} to new messages in ${textChannel.name} after 30 seconds.`);

            // Listen for new messages in the channel
            messageListener.on('collect', async (msg) => {
                // Ignore messages from bots
                if (msg.author.bot) return;

                // Wait 30 seconds before reacting to the message
                setTimeout(async () => {
                    try {
                        await msg.react(emoji); // React with the specified emoji
                    } catch (error) {
                        console.error("Error reacting to message:", error);
                    }
                }, 30 * 1000); // 30 seconds in milliseconds
            });

            // Store the listener so it can be stopped later
            if (!client.reactionListeners) client.reactionListeners = {};
            client.reactionListeners[textChannelId] = messageListener;

        } catch (error) {
            console.error("Error occurred during the event:", error);
            message.channel.send("An error occurred while trying to set up reactions.");
        }
    }
};
